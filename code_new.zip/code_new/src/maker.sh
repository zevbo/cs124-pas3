#!/usr/bin/env bash

cargo build
mv ./target/debug/code ./kk